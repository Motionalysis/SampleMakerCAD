#!/bin/sh -xe

brew update
brew upgrade cmake libpng
