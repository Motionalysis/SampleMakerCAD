#include <solvespace.h>
namespace SolveSpace {
	// SketchParam

	unsigned int SketchParam::ID = 0;

	void SketchParam::Renew(void)
	{
		ID = 0;
	}

	SketchParam::SketchParam(double val)
		: refs(), id(++ID), value(val)
	{}

	double SketchParam::ParseValue(std::string str)
	{
		double v;
		try
		{
			v = std::stod(str, nullptr);
		}
		catch (const std::invalid_argument&) {
			throw "incorrect value.";
		}
		catch (const std::out_of_range&) {
			throw "passed value is out of range.";
		}
		catch (...) {
			throw "unknown error while parsing parameter value.";
		}
		return v;
	}

	unsigned int SketchParam::RefCount() const
	{
		return refs.size();
	}

	void SketchParam::AddRef(hConstraint h)
	{
		auto res = find_if(refs.begin(), refs.end(), [&h](hConstraint c) { return c.v == h.v; });
		if (res == refs.end())
			refs.push_back(h);
	}

	void SketchParam::RemoveRef(hConstraint h)
	{
		auto res = find_if(refs.begin(), refs.end(), [&h](hConstraint c) { return c.v == h.v; });
		if (res != refs.end())
			refs.erase(res);
	}

	void SketchParam::Do(std::function<void(Constraint*)> func)
	{
		for (auto h : refs)
		{
			auto constraint = SK.GetConstraint(h);
			if (constraint != nullptr)
				func(constraint);
		}
	}



	// SketchParamTable

	void SketchParamTable::SetSketchStatus(SketchStatus status)
	{
		sketchStatus = status == STATUS_INIT
			? STATUS_INIT
			: STATUS_INIT_DONE;
	}

	std::map<std::string, SketchParam*> SketchParamTable::GetParameters(void) const
	{
		return params;
	}

	SketchParam* SketchParamTable::Insert(std::string name, double value)
	{
		auto param = new SketchParam(value);
		params.insert({ name, param });
		return param;
	}

	SketchParam* SketchParamTable::Insert(std::string name, std::string value)
	{
		auto v = SketchParam::ParseValue(value);
		auto param = new SketchParam(v);
		params.insert({ name, param });
		return param;
	}

	SketchParam* SketchParamTable::Get(unsigned int id)
	{
		for (auto param : params)
			if (param.second->id == id) return param.second;
		return nullptr;
	}

	SketchParam* SketchParamTable::Get(std::string name)
	{
		auto res = params.find(name);
		if (res != params.end())
			return res->second;
		return nullptr;
	}

	void SketchParamTable::Clear(void)
	{
		SketchParam::Renew();
		for (auto param : params)
			delete param.second;
		params.clear();
	}

	void SketchParamTable::Refresh()
	{
		if (sketchStatus != STATUS_INIT_DONE) return;

		std::list<std::string> unused;
		// storing unused params
		for (auto param : params)
		{
			if (param.second->RefCount() == 0)
			{
				unused.push_back(param.first);
				delete param.second;
			}
		}
		// deleteting unused params from dictionary
		for (auto param : unused)
		{
			params.erase(param);
		}
	}


	// Sketch Restriction

	unsigned int SketchRestriction::ID = 0;

	void SketchRestriction::Renew(void)
	{
		ID = 0;
	}

	SketchRestriction::SketchRestriction(std::string e, std::list<SketchParam*> *params)
		: sketchParams(), id(++ID), eq(e)
	{
		StoreLinksToUsedParams(params);
	}

	void SketchRestriction::Update(std::string e, std::list<SketchParam*> *params)
	{
		sketchParams.clear();
		eq = e;
		StoreLinksToUsedParams(params);
	}

	void SketchRestriction::StoreLinksToUsedParams(std::list<SketchParam*> *params)
	{
		if (params == nullptr)
			return;

		for (auto param : *params)
		{
			auto res = find_if(sketchParams.begin(), sketchParams.end(), [&param](SketchParam* p) { return p->id == param->id; });
			if (res == sketchParams.end())
				sketchParams.push_back(param);
		}
	}

	bool SketchRestriction::IsValid()
	{
		if (sketchParams.size() < 1)
			return false;

		for (auto param : sketchParams)
		{
			if (param->RefCount() == 0)
				return false;
		}
		return true;
	}



	// Sketch Restriction Table

	void SketchRestrictionTable::SetSketchStatus(SketchStatus status)
	{
		sketchStatus = status == STATUS_INIT
			? STATUS_INIT
			: STATUS_INIT_DONE;
	}

	std::list<SketchRestriction*> SketchRestrictionTable::GetRestrictions(void) const
	{
		return restrictions;
	}

	SketchRestriction* SketchRestrictionTable::Get(unsigned int id)
	{
		for (auto r : restrictions)
			if (r->id == id) return r;
		return nullptr;
	}

	SketchRestriction* SketchRestrictionTable::Insert(SketchRestriction *r)
	{
		restrictions.push_back(r);
		return r;
	}

	void SketchRestrictionTable::Remove(unsigned int id)
	{
		auto r = Get(id);
		if(r != nullptr)
			restrictions.remove(r);
	}

	void SketchRestrictionTable::Clear(void)
	{
		SketchRestriction::Renew();
		for (auto r : restrictions)
			delete r;
		restrictions.clear();
	}

	void SketchRestrictionTable::Refresh()
	{
		if (sketchStatus != STATUS_INIT_DONE) return;

		std::list<SketchRestriction*> unused;
		// storing unused restrictions
		for (auto r : restrictions)
		{
			if (!r->IsValid())
				unused.push_back(r);
		}

		// deleteting unused restriction
		for (auto r : unused)
			restrictions.remove(r);
	}


	// Sketch Param System

	void SketchParamSystem::SetSketchStatus(SketchStatus status)
	{
		restrictionTable.SetSketchStatus(status);
		paramTable.SetSketchStatus(status);
	}

	void SketchParamSystem::Clear()
	{
		restrictionTable.Clear();
		paramTable.Clear();
	}

	void SketchParamSystem::Refresh()
	{
		restrictionTable.Refresh();
		paramTable.Refresh();
	}

	SketchParamTable SketchParamSystem::ParamTable() const
	{
		return paramTable;
	}

	SketchRestrictionTable SketchParamSystem::RestrictionTable() const
	{
		return restrictionTable;
	}

	SketchParam *SketchParamSystem::GetParam(std::string name)
	{
		return paramTable.Get(name);
	}

	SketchParam *SketchParamSystem::GetParam(unsigned int id)
	{
		return paramTable.Get(id);
	}

	SketchParam *SketchParamSystem::AddParam(std::string name, std::string value)
	{
		return paramTable.Insert(name, value);
	}

	SketchParam *SketchParamSystem::AddParam(std::string name, double value)
	{
		return paramTable.Insert(name, value);
	}

	void SketchParamSystem::UpdateParam(SketchParam *param, double value)
	{
		if (param == nullptr)
			throw "Unknown parameter.";

		auto oldValue = param->value;
		try
		{
			param->value = value;
			ValidateAllRestrictions();
		}
		catch (...)
		{
			param->value = oldValue;
			throw;
		}
	}

	SketchParam *SketchParamSystem::UpdateParam(unsigned int id, double value)
	{
		auto param = GetParam(id);
		UpdateParam(param, value);
		return param;
	}

	SketchParam *SketchParamSystem::UpdateParam(unsigned int id, std::string value)
	{
		auto param = GetParam(id);
		auto v = SketchParam::ParseValue(value);
		UpdateParam(param, v);
		return param;
	}

	SketchParam *SketchParamSystem::UpdateParam(std::string name, double value)
	{
		auto param = GetParam(name);
		UpdateParam(param, value);
		return param;
	}

	SketchParam *SketchParamSystem::UpdateParam(std::string name, std::string value)
	{
		auto param = GetParam(name);
		auto v = SketchParam::ParseValue(value);
		UpdateParam(param, v);
		return param;
	}


	void SketchParamSystem::ValidateRestriction(std::string eq, std::list<SketchParam *> *constraintParamList)
	{
		auto e = Expr::From(eq.c_str(), false, constraintParamList, [=](std::string name) {
			auto p = this->GetParam(name);
			if (p != nullptr) return p;
			throw "Unknown parameter '" + name + "'.";
		});

		if(static_cast<int>(e->Eval()) == 0)
			throw "Parameters restriction failed: \"" + eq + "\".";
	}

	void SketchParamSystem::ValidateAllRestrictions()
	{
		for (auto r : restrictionTable.GetRestrictions())
			ValidateRestriction(r->eq);
	}

	SketchRestriction *SketchParamSystem::GetRestriction(unsigned int id)
	{
		return restrictionTable.Get(id);
	}

	SketchRestriction *SketchParamSystem::AddRestriction(std::string eq)
	{
		std::list<SketchParam *> params;
		ValidateRestriction(eq, &params);
		return restrictionTable.Insert(new SketchRestriction(eq, &params));
	}

	SketchRestriction *SketchParamSystem::UpdateRestriction(unsigned int id, std::string eq)
	{
		auto r = GetRestriction(id);
		if (r == nullptr)
			throw "Unknown parameter restriction.";

		std::list<SketchParam *> params;
		ValidateRestriction(eq, &params);
		r->Update(eq, &params);
		return r;
	}

	void SketchParamSystem::RemoveRestriction(unsigned int id)
	{
		restrictionTable.Remove(id);
	}

	void SketchParamSystem::UpdateSketchParameters(std::map<std::string, std::string> params)
	{
		std::map<std::string, double> convertedParams;
		for (auto param : params)
		{
			auto v = SketchParam::ParseValue(param.second);
			convertedParams.insert({ param.first, v });
		}
		UpdateSketchParameters(convertedParams);
	}

	void SketchParamSystem::UpdateSketchParameters(std::map<std::string, double> params)
	{
		auto paramsDict = paramTable.GetParameters();

		std::map<unsigned int, double> paramsBackup;
		for (auto param : paramsDict)
			paramsBackup.insert({ param.second->id, param.second->value });

		for (auto param : params)
			paramsDict[param.first]->value = param.second;

		try
		{
			ValidateAllRestrictions();
		}
		catch(...)
		{
			for (auto param : paramsDict)
				paramsDict[param.first]->value = paramsBackup[param.second->id];
			throw;
		}
	}
}